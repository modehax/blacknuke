nano start.sh
echo Configuration done.
echo Do help.sh for more details.
echo Config zombies
cd zombies
nano zombie1.sh
echo Config done
